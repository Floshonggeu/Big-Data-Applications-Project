import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics
from sklearn.ensemble import GradientBoostingClassifier
import xgboost as xgb
import mlflow
import mlflow.sklearn
import numpy as np

def choosemodel():
    choice = int(input("What model do you want to use?\n Write '1' for Random Forest,\n Write '2' for Gradient Boosting,\n Write '3' for XGBoost"))
    return choice

def eval_metrics(Y_test, targets):
       msqe = np.sqrt(mean_squared_error(Y_test, targets))
       mae = mean_absolute_error(Y_test, targets)
       r2 = r2_score(Y_test, targets)
       # Calculating accuracy using scikit-learn
       accuracy = metrics.accuracy_score(Y_test, targets)
       return msqe, mae, r2, accuracy

data_train = pd.read_csv(r"\Users\jbric\Documents\Projets\application_train.csv")

data_train = pd.get_dummies(data_train, columns = ['NAME_CONTRACT_TYPE', 'CODE_GENDER', 'FLAG_OWN_CAR', 'FLAG_OWN_REALTY', 'NAME_TYPE_SUITE', 'NAME_INCOME_TYPE', 'NAME_EDUCATION_TYPE', 'NAME_FAMILY_STATUS', 'NAME_HOUSING_TYPE', 'OCCUPATION_TYPE', 'WEEKDAY_APPR_PROCESS_START', 'ORGANIZATION_TYPE', 'FONDKAPREMONT_MODE', 'HOUSETYPE_MODE', 'WALLSMATERIAL_MODE', 'EMERGENCYSTATE_MODE'])

Y = data_train['TARGET']
X = data_train.drop(columns = ['TARGET'])

X_train, X_test, Y_train, Y_test = train_test_split(X, Y)

choice = 0

while ((choice != 1) and (choice != 2) and (choice != 3)):
    choice = choosemodel()
    if ((choice != 1) and (choice != 2) and (choice != 3)):
        print("You have to write 1, 2, or 3! Try again")

estimators = int(input("How many estimators do you want?"))

# Launching mlflow and select the chosen model
with mlflow.start_run():
    if (choice == 1):
        model = RandomForestClassifier(n_estimators = estimators)
    elif (choice == 2):
        model = GradientBoostingClassifier(n_estimators = estimators)
    elif (choice == 3):
        model = xgb.XGBClassifier(n_estimators = estimators, use_label_encoder = False)
    # Fitting the model
    model.fit(X_train, Y_train)
    # Predicting targets
    targets = model.predict(X_test)
    # Calculating metrics
    (msqe, mae, r2, accuracy) = eval_metrics(Y_test, targets)
    # Logging parameters to MLflow
    mlflow.log_param("model", choice)
    mlflow.log_param("estimators", estimators)
    # Logging metrics to MLflow
    mlflow.log_metric("msqe", msqe)
    mlflow.log_metric("mae", mae)
    mlflow.log_metric("r2", r2)
    mlflow.log_metric("accuracy", accuracy)
    # Logging model to MLflow
    mlflow.sklearn.log_model(model, "model")

print("yes")